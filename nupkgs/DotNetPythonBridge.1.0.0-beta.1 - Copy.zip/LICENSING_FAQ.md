## Licensing FAQ

### Is this open source?
This project is source-available but not OSI open-source.
It is free for non-commercial use under the Polyform Noncommercial License.

### Can I use this at work?
Only if your use is non-commercial.
Most workplace and company usage requires a commercial license.

### Can I use this in a SaaS or paid product?
No, not without a commercial license.

### Can I evaluate it before buying?
Yes. Evaluation and testing are allowed under the non-commercial license.

### Do I need a license just to build or test it?
No, as long as the use is non-commercial.

### What if I'm unsure whether my use is commercial?
Contact us at dotnetpythonbridge@gmail.com

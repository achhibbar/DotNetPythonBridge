﻿# Commercial License

Commercial use of this software requires a paid license.

This includes, but is not limited to:
- Use within a company or organization
- Use in paid or revenue-generating products or services
- SaaS, hosted services, or internal tools
- Consulting or client work involving this software

A commercial license grants:
- The right to use the software for commercial purposes
- The right to distribute the software as part of a commercial product
- Priority support (if offered)

Commercial licenses will be available via:
> 🔗 Lemon Squeezy (coming soon)

Until then, please contact:
> dotnetpythonbridge@gmail.com
